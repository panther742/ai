//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DJmCr4Wj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/shiva/Downloads/lovable-project-22a4aa3e/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DIOMqVHB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DIOMqVHB.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/shiva/Downloads/lovable-project-22a4aa3e/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-_ZprZ8x0.js"]
	}
} });
//#endregion
export { tsrStartManifest };

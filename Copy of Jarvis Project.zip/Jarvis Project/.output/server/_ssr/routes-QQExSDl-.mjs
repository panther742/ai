import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { A as Activity, C as Cloud, D as Brain, E as Calendar, M as CircleCheck, O as Bell, S as Cpu, T as Car, _ as Globe, a as TrendingDown, b as Eye, c as Send, d as Mic, f as MessageSquare, g as Heart, h as Linkedin, i as TrendingUp, j as Sparkles, k as Battery, l as Search, m as Mail, n as Wrench, o as Slack, p as MapPin, r as Wifi, s as Signal, t as Zap, u as Music, v as Github, w as Clock, x as Database, y as FileText } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-QQExSDl-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useNow() {
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const i = setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => clearInterval(i);
	}, []);
	return now;
}
function useTicker(initial, range = 4, ms = 1400) {
	const [v, setV] = (0, import_react.useState)(initial);
	(0, import_react.useEffect)(() => {
		const i = setInterval(() => {
			setV((p) => Math.max(0, Math.min(100, p + (Math.random() - .5) * range)));
		}, ms);
		return () => clearInterval(i);
	}, [range, ms]);
	return v;
}
function Particles() {
	const dots = (0, import_react.useMemo)(() => Array.from({ length: 60 }).map(() => ({
		x: Math.random() * 100,
		y: Math.random() * 100,
		s: Math.random() * 2 + .5,
		d: Math.random() * 10 + 8,
		delay: -Math.random() * 10,
		hue: Math.random() > .5 ? "210" : "290"
	})), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none fixed inset-0 z-0 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 grid-bg opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute -top-40 -left-40 h-[600px] w-[600px] rounded-full bg-[radial-gradient(circle,oklch(1_0_0/0.05),transparent_70%)] blur-3xl",
				style: { animation: "drift 18s ease-in-out infinite" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute -bottom-40 -right-40 h-[700px] w-[700px] rounded-full bg-[radial-gradient(circle,oklch(1_0_0/0.04),transparent_70%)] blur-3xl",
				style: { animation: "drift 22s ease-in-out infinite reverse" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-1/3 right-1/4 h-[400px] w-[400px] rounded-full bg-[radial-gradient(circle,oklch(1_0_0/0.03),transparent_70%)] blur-3xl",
				style: { animation: "drift 14s ease-in-out infinite" }
			}),
			dots.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute rounded-full",
				style: {
					left: `${p.x}%`,
					top: `${p.y}%`,
					width: p.s,
					height: p.s,
					background: `oklch(0.9 0.2 ${p.hue})`,
					boxShadow: `0 0 ${p.s * 4}px oklch(0.8 0.2 ${p.hue})`,
					animation: `float-y ${p.d}s ease-in-out ${p.delay}s infinite`
				}
			}, i))
		]
	});
}
function TopBar({ speaking, setSpeaking }) {
	const now = useNow();
	const cpu = useTicker(34, 12);
	const lat = useTicker(42, 8, 1e3);
	const time = now.toLocaleTimeString("en-US", {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hour12: false
	});
	const date = now.toLocaleDateString("en-US", {
		weekday: "long",
		month: "long",
		day: "numeric",
		year: "numeric"
	});
	const hour = now.getHours();
	const greeting = hour < 12 ? "Good Morning" : hour < 18 ? "Good Afternoon" : "Good Evening";
	const stat = (icon, label, value, color = "text-cyan") => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 px-3 py-1.5 rounded-full glass",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: color,
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] uppercase tracking-[0.18em] text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-mono font-medium text-foreground",
				children: value
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "relative z-20 flex items-center justify-between gap-6 px-8 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-11 w-11 rounded-2xl glass flex items-center justify-center",
						style: { animation: "glow-pulse 3s ease-in-out infinite" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5 text-cyan" })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "leading-tight",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] uppercase tracking-[0.4em] text-foreground/70",
						children: "Shivang's PA · OS v4.2"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-2xl font-light tracking-tight",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gradient font-semibold",
							children: greeting
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground/80",
							children: ", Shivang."
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 flex-wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSpeaking(!speaking),
					className: `flex items-center gap-2 rounded-full border px-3 py-1.5 text-[10px] uppercase tracking-[0.24em] transition ${speaking ? "border-cyan/50 bg-cyan/10 text-cyan" : "border-white/10 bg-white/[0.03] text-foreground/80 hover:border-cyan/40"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "h-3.5 w-3.5" }), speaking ? "Live" : "Standby"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden lg:flex items-center gap-2",
					children: [
						stat(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-3.5 w-3.5" }), "Gemini", "Online", "text-emerald-400"),
						stat(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, { className: "h-3.5 w-3.5" }), "CPU", `${cpu.toFixed(0)}%`),
						stat(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signal, { className: "h-3.5 w-3.5" }), "Lat", `${lat.toFixed(0)}ms`),
						stat(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "h-3.5 w-3.5" }), "Net", "1.2 Gb/s"),
						stat(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Battery, { className: "h-3.5 w-3.5" }), "Pwr", "94%", "text-emerald-400")
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-right leading-tight",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-3xl font-light tracking-tight neon-text tabular-nums",
					children: time
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] uppercase tracking-[0.3em] text-muted-foreground",
					children: date
				})]
			})
		]
	});
}
function Orb({ speaking }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex items-center justify-center",
		style: {
			width: 460,
			height: 460
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 rounded-full border border-cyan/20",
				style: { animation: "spin-slow 28s linear infinite" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rounded-full bg-cyan shadow-[0_0_18px_oklch(0.85_0.18_210)]" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-6 rounded-full border border-violet/20",
				style: { animation: "spin-rev 22s linear infinite" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-1/2 -right-1.5 h-2.5 w-2.5 -translate-y-1/2 rounded-full bg-violet shadow-[0_0_18px_oklch(0.65_0.27_295)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-1.5 left-1/4 h-2 w-2 rounded-full bg-magenta shadow-[0_0_16px_oklch(0.7_0.28_330)]" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-14 rounded-full border border-azure/30",
				style: { animation: "spin-slow 16s linear infinite" }
			}),
			[
				0,
				1,
				2
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-20 rounded-full border-2 border-cyan/40",
				style: { animation: `pulse-ring 3s ease-out ${i * 1}s infinite` }
			}, i)),
			Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute h-2 w-2 rounded-full",
				style: {
					background: i % 2 ? "oklch(0.85 0.18 210)" : "oklch(0.7 0.27 295)",
					boxShadow: "0 0 14px currentColor",
					color: i % 2 ? "oklch(0.85 0.18 210)" : "oklch(0.7 0.27 295)",
					"--r": `${130 + i % 3 * 18}px`,
					animation: `particle-orbit ${10 + i * 1.4}s linear ${-i * .7}s infinite`
				}
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-56 w-56 rounded-full",
				style: {
					background: "radial-gradient(circle at 35% 30%, oklch(0.95 0.05 210) 0%, oklch(0.78 0.2 230) 18%, oklch(0.5 0.25 270) 50%, oklch(0.2 0.15 290) 80%)",
					boxShadow: "inset 0 -30px 60px oklch(0.2 0.15 290 / 0.9), inset 0 30px 60px oklch(0.95 0.1 210 / 0.4), 0 0 80px oklch(0.6 0.25 250 / 0.7), 0 0 160px oklch(0.55 0.25 280 / 0.5)",
					animation: `orb-breathe ${speaking ? 1.2 : 3.6}s ease-in-out infinite`
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-6 rounded-full opacity-60 mix-blend-screen",
						style: {
							background: "conic-gradient(from 0deg, transparent, oklch(0.9 0.2 210 / 0.6), transparent 40%, oklch(0.7 0.27 305 / 0.5), transparent 80%)",
							animation: "spin-slow 8s linear infinite"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-12 rounded-full bg-[radial-gradient(circle_at_40%_35%,oklch(1_0_0/0.5),transparent_60%)]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 flex items-center justify-center gap-1",
						children: Array.from({ length: 7 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-1 rounded-full bg-white/90",
							style: {
								height: 14 + i % 3 * 8,
								boxShadow: "0 0 8px oklch(0.95 0.1 210)",
								animation: `wave ${.7 + i % 3 * .2}s ease-in-out ${-i * .1}s infinite`
							}
						}, i))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute -bottom-2 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-1.5 rounded-full glass",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_10px_oklch(0.7_0.18_150)]",
					style: { animation: "blink 1.5s infinite" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] uppercase tracking-[0.3em] text-foreground/80",
					children: speaking ? "Speaking" : "Listening"
				})]
			})
		]
	});
}
function Panel({ title, eyebrow, icon, children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `glass rounded-2xl p-5 ${className}`,
		style: { animation: "float-y 8s ease-in-out infinite" },
		children: [(title || eyebrow) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[9px] uppercase tracking-[0.35em] text-muted-foreground",
				children: eyebrow
			}), title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-medium text-foreground/90 mt-0.5",
				children: title
			})] }), icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-cyan/80",
				children: icon
			})]
		}), children]
	});
}
function SchedulePanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		eyebrow: "Today",
		title: "Schedule",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2.5",
			children: [
				{
					t: "09:30",
					title: "Standup · Engineering",
					meta: "Zoom · 6 attendees",
					color: "from-cyan/60 to-azure/30"
				},
				{
					t: "11:00",
					title: "Content Making",
					meta: "Studio · script + shoot",
					color: "from-violet/60 to-magenta/30"
				},
				{
					t: "13:15",
					title: "Lunch",
					meta: "Blue Tokai, Koregaon",
					color: "from-emerald-400/60 to-cyan/20"
				},
				{
					t: "15:00",
					title: "Product Review",
					meta: "SARA v4.3 launch",
					color: "from-magenta/50 to-violet/20"
				},
				{
					t: "18:30",
					title: "Gym · Strength",
					meta: "Cult · 60 min",
					color: "from-amber-400/50 to-orange-500/20"
				}
			].map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "group relative flex items-center gap-3 p-2.5 rounded-xl bg-white/[0.02] border border-white/5 hover:border-cyan/30 transition-all hover:translate-x-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `w-1 self-stretch rounded-full bg-gradient-to-b ${it.color}` }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-xs text-cyan w-12 tabular-nums",
						children: it.t
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-foreground truncate",
							children: it.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] text-muted-foreground truncate",
							children: it.meta
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "opacity-0 group-hover:opacity-100 transition-opacity text-cyan/70",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" })
					})
				]
			}, i))
		})
	});
}
function TasksPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		eyebrow: "Focus",
		title: "Tasks",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: [
				{
					t: "Ship voice mode v2",
					done: true
				},
				{
					t: "Review pull request #482",
					done: false
				},
				{
					t: "Sign Acme contract",
					done: false
				},
				{
					t: "Write Q3 OKRs draft",
					done: false
				}
			].map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `h-4 w-4 rounded-md border ${t.done ? "bg-cyan/30 border-cyan" : "border-white/20"} flex items-center justify-center`,
					children: t.done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3 text-cyan" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: t.done ? "text-muted-foreground line-through" : "text-foreground/90",
					children: t.t
				})]
			}, i))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 h-1 rounded-full bg-white/5 overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full w-1/4 rounded-full bg-gradient-to-r from-cyan to-violet",
				style: { animation: "gradient-x 4s ease infinite" }
			})
		})]
	});
}
function WeatherPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		eyebrow: "Delhi · 19:42",
		title: "Climate",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "h-4 w-4" }),
		className: "!p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-4xl font-light tabular-nums text-gradient",
				children: "41°"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] text-foreground/70",
				children: "Hot · feels 44°"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-right text-[10px] text-muted-foreground space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, { className: "h-3 w-3 text-cyan" }), " 24 min · light traffic"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "Humidity 64% · UV 6" })]
			})]
		})
	});
}
function ThinkingPanel() {
	const [step, setStep] = (0, import_react.useState)(0);
	const steps = [
		{
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "h-3.5 w-3.5" }),
			label: "Parsing intent",
			detail: "input → semantic graph"
		},
		{
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "h-3.5 w-3.5" }),
			label: "Retrieving memory",
			detail: "vector · 1,284 docs"
		},
		{
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "h-3.5 w-3.5" }),
			label: "Calling tool",
			detail: "calendar.find_slot()"
		},
		{
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "h-3.5 w-3.5" }),
			label: "Composing reply",
			detail: "tone: focused"
		}
	];
	(0, import_react.useEffect)(() => {
		const i = setInterval(() => setStep((s) => (s + 1) % (steps.length + 1)), 1800);
		return () => clearInterval(i);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		eyebrow: "Live",
		title: "AI Reasoning",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "h-4 w-4" }),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: steps.map((s, i) => {
				const active = i === step;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex items-start gap-3 p-2 rounded-lg transition-all ${active ? "bg-cyan/5 border border-cyan/30" : "border border-transparent"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `mt-0.5 h-6 w-6 rounded-md flex items-center justify-center ${active ? "bg-cyan/20 text-cyan" : i < step ? "bg-emerald-400/10 text-emerald-400" : "bg-white/5 text-muted-foreground"}`,
						children: s.icon
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-foreground/90 flex items-center gap-2",
							children: [s.label, active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-block w-1.5 h-3 bg-cyan",
								style: { animation: "type-cursor 0.8s infinite" }
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] text-muted-foreground font-mono",
							children: s.detail
						})]
					})]
				}, i);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 pt-3 border-t border-white/5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[9px] uppercase tracking-[0.3em] text-muted-foreground mb-1.5",
				children: "Agent logs"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "font-mono text-[10px] text-muted-foreground/80 space-y-0.5 max-h-24 overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-cyan",
						children: "[19:42:11]"
					}), " route → assistant.primary"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-violet",
						children: "[19:42:11]"
					}), " ctx · 8.4k tokens loaded"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-emerald-400",
						children: "[19:42:12]"
					}), " tool calendar.find_slot OK 184ms"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-cyan",
						children: "[19:42:12]"
					}), " stream → user · 38 tok/s"] })
				]
			})]
		})]
	});
}
function WorldMap() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		eyebrow: "Global · Live",
		title: "Network Activity",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "h-4 w-4" }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative w-full aspect-square max-h-[220px] mx-auto rounded-xl overflow-hidden bg-[radial-gradient(circle_at_center,oklch(0.18_0.06_240/0.6),transparent_70%)] flex items-center justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-4 rounded-full",
					style: { boxShadow: "0 0 80px 10px oklch(0.7 0.22 220 / 0.25), inset 0 0 60px oklch(0.7 0.22 220 / 0.15)" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					style: {
						width: "70%",
						aspectRatio: "1"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-0 rounded-full overflow-hidden border border-cyan/30",
							style: {
								background: "radial-gradient(circle at 30% 30%, oklch(0.28 0.08 240) 0%, oklch(0.1 0.04 250) 60%, oklch(0.06 0.02 250) 100%)",
								boxShadow: "inset -30px -20px 80px rgba(0,0,0,0.7), inset 20px 10px 40px oklch(0.6 0.2 220 / 0.25)"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 200 200",
								className: "absolute inset-0 w-full h-full",
								style: { animation: "spin-slow 18s linear infinite" },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
										id: "globeMask",
										cx: "50%",
										cy: "50%",
										r: "50%",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "80%",
											stopColor: "white",
											stopOpacity: "1"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "white",
											stopOpacity: "0"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mask", {
										id: "gMask",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "100",
											cy: "100",
											r: "100",
											fill: "url(#globeMask)"
										})
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
										mask: "url(#gMask)",
										fill: "none",
										stroke: "oklch(0.85 0.18 210)",
										strokeWidth: "0.5",
										opacity: "0.55",
										children: [
											[
												10,
												25,
												40,
												55,
												70,
												85
											].map((rx, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
												cx: "100",
												cy: "100",
												rx,
												ry: "85"
											}, i)),
											[
												20,
												40,
												60,
												75,
												85
											].map((ry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
												cx: "100",
												cy: "100",
												rx: "92",
												ry
											}, i)),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
												x1: "6",
												y1: "100",
												x2: "194",
												y2: "100",
												stroke: "oklch(0.9 0.2 200)",
												strokeWidth: "0.7",
												opacity: "0.7"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
										mask: "url(#gMask)",
										fill: "oklch(0.85 0.18 200)",
										opacity: "0.85",
										children: Array.from({ length: 90 }).map((_, i) => {
											const a = i * 137.5 % 360;
											const r = 30 + i * 17 % 65;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
												cx: 100 + Math.cos(a * Math.PI / 180) * r,
												cy: 100 + Math.sin(a * Math.PI / 180) * r * .95,
												r: .7 + i % 3 * .25
											}, i);
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 rounded-full pointer-events-none",
								style: { background: "radial-gradient(circle at 28% 22%, rgba(255,255,255,0.18), transparent 35%)" }
							})]
						}),
						[
							{
								r: 44,
								dur: 14,
								count: 3,
								color: "oklch(0.85 0.18 210)"
							},
							{
								r: 62,
								dur: 22,
								count: 4,
								color: "oklch(0.78 0.20 280)"
							},
							{
								r: 80,
								dur: 32,
								count: 2,
								color: "oklch(0.82 0.20 330)"
							}
						].map((o, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute left-1/2 top-1/2 rounded-full border border-white/10",
							style: {
								width: `${o.r * 2}%`,
								height: `${o.r * 2}%`,
								transform: "translate(-50%, -50%) rotateX(72deg)",
								animation: `spin-slow ${o.dur}s linear infinite${idx % 2 ? " reverse" : ""}`,
								borderColor: "oklch(0.8 0.18 220 / 0.25)"
							},
							children: Array.from({ length: o.count }).map((_, i) => {
								const angle = 360 / o.count * i;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-1/2 left-1/2",
									style: { transform: `rotate(${angle}deg) translateX(${o.r}%) rotate(-${angle}deg)` },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-2 w-2 rounded-full",
										style: {
											background: o.color,
											boxShadow: `0 0 12px ${o.color}`
										}
									})
								}, i);
							})
						}, idx)),
						[
							{
								x: 30,
								y: 35
							},
							{
								x: 68,
								y: 42
							},
							{
								x: 55,
								y: 68
							},
							{
								x: 40,
								y: 60
							}
						].map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute",
							style: {
								left: `${n.x}%`,
								top: `${n.y}%`,
								transform: "translate(-50%,-50%)"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 rounded-full bg-cyan/40",
								style: {
									width: 14,
									height: 14,
									marginLeft: -7,
									marginTop: -7,
									animation: `node-pulse 2s ease-out ${-i * .4}s infinite`
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 w-1.5 rounded-full bg-cyan shadow-[0_0_10px_oklch(0.85_0.18_210)]" })]
						}, i))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-2 right-3 text-[10px] font-mono text-foreground/70",
					children: "28 nodes · 1.4k req/s"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-2 left-3 text-[10px] font-mono text-foreground/70",
					children: "orbit · stable"
				})
			]
		})
	});
}
function MiniStat({ label, value, change, up, spark }) {
	const max = Math.max(...spark), min = Math.min(...spark);
	const pts = spark.map((v, i) => `${i / (spark.length - 1) * 100},${30 - (v - min) / (max - min || 1) * 28}`).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-xl p-3 flex flex-col gap-1.5 hover:border-cyan/30 transition",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: `text-[10px] font-mono flex items-center gap-0.5 ${up ? "text-emerald-400" : "text-rose-400"}`,
					children: [
						up ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-3 w-3" }),
						" ",
						change
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-light tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 100 32",
				className: "w-full h-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
					points: pts,
					fill: "none",
					stroke: up ? "oklch(0.75 0.2 160)" : "oklch(0.7 0.22 25)",
					strokeWidth: "1.5"
				})
			})
		]
	});
}
function StatsGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-2.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
				label: "NVDA",
				value: "$948.32",
				change: "+2.4%",
				up: true,
				spark: [
					3,
					4,
					3,
					5,
					6,
					5,
					7,
					8,
					7,
					9,
					10
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
				label: "BTC",
				value: "$71.2k",
				change: "+1.8%",
				up: true,
				spark: [
					5,
					4,
					6,
					5,
					7,
					6,
					8,
					7,
					9,
					8,
					10
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
				label: "ETH",
				value: "$3.84k",
				change: "-0.6%",
				up: false,
				spark: [
					8,
					9,
					7,
					8,
					6,
					7,
					5,
					6,
					4,
					5,
					3
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
				label: "AAPL",
				value: "$224.18",
				change: "+0.9%",
				up: true,
				spark: [
					2,
					3,
					2,
					4,
					3,
					5,
					4,
					6,
					5,
					7,
					6
				]
			})
		]
	});
}
function QuickPanels() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2.5",
		children: [
			{
				i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-3.5 w-3.5" }),
				l: "Inbox",
				v: "12 unread",
				g: "from-cyan/30"
			},
			{
				i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-3.5 w-3.5" }),
				l: "Alerts",
				v: "3 new",
				g: "from-violet/30"
			},
			{
				i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Github, { className: "h-3.5 w-3.5" }),
				l: "Commits",
				v: "8 today",
				g: "from-magenta/30"
			},
			{
				i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-3.5 w-3.5" }),
				l: "Heart",
				v: "72 bpm",
				g: "from-rose-400/30"
			}
		].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `glass rounded-xl p-3 bg-gradient-to-br ${x.g} to-transparent`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1.5 text-cyan/90",
				children: [x.i, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground",
					children: x.l
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm mt-1 text-foreground/90",
				children: x.v
			})]
		}, i))
	});
}
function Productivity() {
	const score = 87;
	const c = 2 * Math.PI * 32;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		eyebrow: "Today",
		title: "Productivity Score",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4" }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 80 80",
				className: "h-20 w-20 -rotate-90",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "40",
						cy: "40",
						r: "32",
						stroke: "oklch(1 0 0 / 0.06)",
						strokeWidth: "6",
						fill: "none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "40",
						cy: "40",
						r: "32",
						stroke: "url(#gscore)",
						strokeWidth: "6",
						fill: "none",
						strokeDasharray: c,
						strokeDashoffset: c - c * score / 100,
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "gscore",
						x1: "0",
						y1: "0",
						x2: "1",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "oklch(0.85 0.18 210)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "oklch(0.7 0.27 305)"
						})]
					}) })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-3xl font-light text-gradient tabular-nums",
					children: score
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] text-muted-foreground",
					children: "Deep focus · 4h 18m"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] text-emerald-400 mt-0.5",
					children: "+12% vs yesterday"
				})
			] })]
		})
	});
}
function Sparkline({ data, color, fill }) {
	const max = Math.max(...data), min = Math.min(...data);
	const w = 100, h = 40;
	const pts = data.map((v, i) => `${i / (data.length - 1) * w},${h - (v - min) / (max - min || 1) * (h - 4) - 2}`).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "w-full h-12",
		preserveAspectRatio: "none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
				id: fill,
				x1: "0",
				y1: "0",
				x2: "0",
				y2: "1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "0",
					stopColor: color,
					stopOpacity: "0.45"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "1",
					stopColor: color,
					stopOpacity: "0"
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: `0,${h} ${pts} ${w},${h}`,
				fill: `url(#${fill})`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
				points: pts,
				stroke: color,
				strokeWidth: "1.4",
				fill: "none"
			})
		]
	});
}
function GraphsRow() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		eyebrow: "Telemetry",
		title: "Realtime Metrics",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-4 w-4" }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 md:grid-cols-6 gap-3",
			children: [
				{
					l: "Revenue",
					v: "$48.2k",
					d: [
						4,
						6,
						5,
						7,
						6,
						8,
						7,
						9,
						8,
						10,
						9,
						11,
						12
					],
					c: "oklch(0.85 0.18 210)",
					k: "rev"
				},
				{
					l: "Focus",
					v: "92%",
					d: [
						6,
						5,
						7,
						6,
						8,
						7,
						9,
						8,
						10,
						9,
						11,
						10,
						12
					],
					c: "oklch(0.7 0.27 305)",
					k: "foc"
				},
				{
					l: "Sleep",
					v: "7h 42m",
					d: [
						3,
						4,
						5,
						4,
						6,
						5,
						7,
						6,
						8,
						7,
						8,
						7,
						8
					],
					c: "oklch(0.75 0.2 160)",
					k: "sl"
				},
				{
					l: "Heart",
					v: "72 bpm",
					d: [
						5,
						7,
						4,
						8,
						5,
						9,
						6,
						8,
						5,
						7,
						6,
						8,
						5
					],
					c: "oklch(0.7 0.22 25)",
					k: "hr"
				},
				{
					l: "CPU",
					v: "34%",
					d: [
						2,
						3,
						4,
						3,
						5,
						4,
						6,
						5,
						4,
						3,
						4,
						5,
						4
					],
					c: "oklch(0.78 0.18 230)",
					k: "cpu"
				},
				{
					l: "Memory",
					v: "12.4 GB",
					d: [
						6,
						6,
						7,
						7,
						8,
						7,
						8,
						9,
						8,
						9,
						9,
						10,
						10
					],
					c: "oklch(0.7 0.25 280)",
					k: "mem"
				}
			].map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[9px] uppercase tracking-[0.25em] text-muted-foreground",
						children: c.l
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-light tabular-nums",
						children: c.v
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
						data: c.d,
						color: c.c,
						fill: c.k
					})
				]
			}, i))
		})
	});
}
function Capabilities() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		eyebrow: "Connected",
		title: "Agent Capabilities",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-4 md:grid-cols-6 gap-2.5",
			children: [
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" }),
					l: "Calendar"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }),
					l: "Gmail"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "h-4 w-4" }),
					l: "WhatsApp"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4" }),
					l: "Notion"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slack, { className: "h-4 w-4" }),
					l: "Slack"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Github, { className: "h-4 w-4" }),
					l: "GitHub"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { className: "h-4 w-4" }),
					l: "LinkedIn"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" }),
					l: "Maps"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "h-4 w-4" }),
					l: "Weather"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" }),
					l: "Search"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4" }),
					l: "Docs"
				},
				{
					i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, { className: "h-4 w-4" }),
					l: "Music"
				}
			].map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "group relative aspect-square rounded-xl glass flex flex-col items-center justify-center gap-1.5 hover:scale-105 hover:border-cyan/40 transition-all cursor-pointer",
				style: { animation: `float-y ${5 + i % 4}s ease-in-out ${-i * .4}s infinite` },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-cyan group-hover:text-violet transition-colors",
						children: c.i
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] text-foreground/70",
						children: c.l
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_oklch(0.75_0.2_150)]" })
				]
			}, i))
		})
	});
}
function MarketsStrip() {
	const rows = [
		{
			sym: "BTC",
			name: "Bitcoin",
			px: "$103,482",
			chg: "+2.14%",
			up: true
		},
		{
			sym: "ETH",
			name: "Ethereum",
			px: "$5,728",
			chg: "+1.62%",
			up: true
		},
		{
			sym: "SOL",
			name: "Solana",
			px: "$284.10",
			chg: "-0.84%",
			up: false
		},
		{
			sym: "NVDA",
			name: "NVIDIA",
			px: "$1,612",
			chg: "+3.42%",
			up: true
		},
		{
			sym: "AAPL",
			name: "Apple",
			px: "$248.90",
			chg: "+0.41%",
			up: true
		},
		{
			sym: "TSLA",
			name: "Tesla",
			px: "$412.55",
			chg: "-1.27%",
			up: false
		},
		{
			sym: "MSFT",
			name: "Microsoft",
			px: "$502.18",
			chg: "+0.92%",
			up: true
		},
		{
			sym: "GOOG",
			name: "Alphabet",
			px: "$214.74",
			chg: "+1.08%",
			up: true
		},
		{
			sym: "META",
			name: "Meta",
			px: "$728.40",
			chg: "+2.21%",
			up: true
		},
		{
			sym: "AMZN",
			name: "Amazon",
			px: "$248.66",
			chg: "-0.32%",
			up: false
		},
		{
			sym: "GOLD",
			name: "Gold / oz",
			px: "$2,914",
			chg: "+0.18%",
			up: true
		},
		{
			sym: "OIL",
			name: "Brent",
			px: "$74.30",
			chg: "-0.61%",
			up: false
		}
	];
	const loop = [...rows, ...rows];
	const spark = (up) => {
		const pts = Array.from({ length: 16 }).map((_, i) => {
			const y = 10 + Math.sin(i * .9 + (up ? 0 : 1.7)) * 4 + (up ? -i * .25 : i * .25);
			return `${i * 6},${y.toFixed(1)}`;
		}).join(" ");
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 96 24",
			className: "w-24 h-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
				fill: "none",
				stroke: up ? "oklch(0.8 0.18 150)" : "oklch(0.7 0.22 25)",
				strokeWidth: "1.4",
				points: pts
			})
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-2xl overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between px-5 py-2.5 border-b border-white/5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3.5 w-3.5 text-foreground/70" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] uppercase tracking-[0.4em] text-foreground/80",
						children: "Markets"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono",
						children: "· streaming"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono",
				children: "12 instruments"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-y-0 left-0 w-24 z-10 bg-gradient-to-r from-[#050505] to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-y-0 right-0 w-24 z-10 bg-gradient-to-l from-[#050505] to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-3 py-3 px-5 whitespace-nowrap",
					style: {
						animation: "ticker 70s linear infinite",
						width: "max-content"
					},
					children: loop.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "shrink-0 flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.025] px-4 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-[0.25em] text-muted-foreground font-mono",
									children: r.sym
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-foreground/90",
									children: r.px
								})]
							}),
							spark(r.up),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-xs font-mono ${r.up ? "text-emerald-400" : "text-red-400"}`,
								children: r.chg
							})
						]
					}, i))
				})
			]
		})]
	});
}
function NewsTicker() {
	const items = [
		{
			cat: "AI",
			src: "TechCrunch",
			time: "2m",
			title: "OpenAI unveils GPT-6 with native agentic reasoning",
			trend: "up",
			delta: "+4.2%"
		},
		{
			cat: "Markets",
			src: "Bloomberg",
			time: "5m",
			title: "NVIDIA hits $4T market cap on Blackwell demand",
			trend: "up",
			delta: "+2.8%"
		},
		{
			cat: "Funding",
			src: "The Information",
			time: "11m",
			title: "Anthropic raises $8B at $120B valuation",
			trend: "up",
			delta: "+12%"
		},
		{
			cat: "Hardware",
			src: "The Verge",
			time: "22m",
			title: "Apple Vision Pro 2 ships with neural eye tracking",
			trend: "up",
			delta: "+1.1%"
		},
		{
			cat: "Robotics",
			src: "Reuters",
			time: "34m",
			title: "Tesla Optimus enters limited consumer pilot",
			trend: "up",
			delta: "+5.6%"
		},
		{
			cat: "Policy",
			src: "FT",
			time: "48m",
			title: "EU passes AI Liability Act, effective 2027",
			trend: "down",
			delta: "-0.4%"
		},
		{
			cat: "Space",
			src: "Ars Technica",
			time: "1h",
			title: "SpaceX Starship completes 14th orbital test",
			trend: "up",
			delta: "+3.0%"
		},
		{
			cat: "Deals",
			src: "WSJ",
			time: "1h",
			title: "Stripe acquires payments AI startup for $1.2B",
			trend: "up",
			delta: "+0.9%"
		},
		{
			cat: "Product",
			src: "Notion",
			time: "2h",
			title: "Notion launches AI workspace agents",
			trend: "up",
			delta: "+2.1%"
		}
	];
	const loop = [...items, ...items];
	const catColor = {
		AI: "text-cyan",
		Markets: "text-emerald-400",
		Funding: "text-violet",
		Hardware: "text-foreground/80",
		Robotics: "text-magenta",
		Policy: "text-amber-400",
		Space: "text-cyan",
		Deals: "text-emerald-400",
		Product: "text-violet"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-2xl overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between px-5 py-2.5 border-b border-white/5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "relative flex h-2 w-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute inset-0 rounded-full bg-emerald-400 opacity-70",
							style: { animation: "pulse-ring 1.6s ease-out infinite" }
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex h-2 w-2 rounded-full bg-emerald-400" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] uppercase tracking-[0.4em] text-foreground/80",
						children: "Live Feed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono",
						children: "· global · realtime"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "9 sources" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-3 w-px bg-white/10" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "auto-curated" })
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-y-0 left-0 w-24 z-10 bg-gradient-to-r from-[#050505] to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-y-0 right-0 w-24 z-10 bg-gradient-to-l from-[#050505] to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-4 py-4 px-5 whitespace-nowrap",
					style: {
						animation: "ticker 90s linear infinite",
						width: "max-content"
					},
					children: loop.map((it, i) => {
						const Up = it.trend === "up";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "group shrink-0 w-[320px] rounded-xl border border-white/8 bg-white/[0.025] hover:bg-white/[0.05] transition-colors px-4 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[9px] uppercase tracking-[0.32em] ${catColor[it.cat] ?? "text-foreground/70"}`,
										children: it.cat
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `flex items-center gap-1 text-[10px] font-mono ${Up ? "text-emerald-400" : "text-red-400"}`,
										children: [Up ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-3 w-3" }), it.delta]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[13px] leading-snug text-foreground/90 whitespace-normal line-clamp-2 group-hover:text-foreground",
									children: it.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex items-center justify-between text-[10px] uppercase tracking-[0.25em] text-muted-foreground font-mono",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: it.src }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-2.5 w-2.5" }), it.time]
									})]
								})
							]
						}, i);
					})
				})
			]
		})]
	});
}
function useSpeechRecognition(active) {
	const [transcript, setTranscript] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("Tap the mic to start listening in your browser.");
	const [supported, setSupported] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
		setSupported(Boolean(Recognition));
		if (!Recognition) {
			setStatus("Browser speech recognition is not supported here.");
			return;
		}
		if (!active) {
			setStatus("Ready to listen");
			return;
		}
		const recognition = new Recognition();
		recognition.continuous = true;
		recognition.interimResults = true;
		recognition.lang = "en-US";
		let finalTranscript = "";
		let interimText = "";
		recognition.onresult = (event) => {
			interimText = "";
			for (let i = event.resultIndex; i < event.results.length; i += 1) {
				const result = event.results[i];
				const text = result[0]?.transcript ?? "";
				if (result.isFinal) finalTranscript = `${finalTranscript} ${text}`.trim();
				else interimText = text;
			}
			const nextTranscript = `${finalTranscript} ${interimText}`.trim();
			setTranscript(nextTranscript);
			setStatus(nextTranscript ? "Listening live…" : "Listening…");
		};
		recognition.onerror = (event) => {
			setStatus(`Speech error: ${event.error}`);
		};
		recognition.onend = () => {
			setStatus(active ? "Listening stopped unexpectedly." : "Ready to listen");
		};
		recognition.start();
		setStatus("Listening live…");
		return () => {
			recognition.stop();
			recognition.onresult = null;
			recognition.onerror = null;
			recognition.onend = null;
		};
	}, [active]);
	return {
		transcript,
		status,
		supported
	};
}
function VoiceBar({ speaking }) {
	const { transcript, status, supported } = useSpeechRecognition(speaking);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-strong rounded-2xl p-5 flex flex-col gap-4 md:flex-row md:items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-14 w-14 rounded-full shrink-0 flex items-center justify-center text-background",
				style: {
					background: "radial-gradient(circle at 30% 30%, oklch(0.95 0.06 210), oklch(0.78 0.2 230) 50%, oklch(0.5 0.25 280))",
					animation: "glow-pulse 2.4s ease-in-out infinite"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "h-6 w-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-0 rounded-full border border-cyan/50",
					style: { animation: "pulse-ring 2s ease-out infinite" }
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[9px] uppercase tracking-[0.3em] text-muted-foreground mb-1.5",
						children: speaking ? "Listening · live transcription" : "Ready · browser speech"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base text-foreground/95 leading-relaxed min-h-[1.5rem]",
						children: transcript || (supported ? "Start listening to capture your words in real time." : "Your browser does not support speech recognition.")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-[11px] text-cyan/80",
						children: status
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-end gap-[3px] h-12",
				children: Array.from({ length: 48 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-[3px] rounded-full bg-gradient-to-t from-cyan via-azure to-violet",
					style: {
						height: `${20 + i * 53 % 80}%`,
						animation: `wave ${.6 + i % 5 * .12}s ease-in-out ${-i * .05}s infinite`,
						opacity: speaking ? 1 : .6
					}
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "hidden md:flex items-center gap-2 px-4 py-2 rounded-full glass text-xs text-foreground/80 hover:border-cyan/40 transition",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-3.5 w-3.5 text-cyan" }), " Send"]
			})
		]
	});
}
var INTRO_LINE = "Hi Boss. Good morning. While you were sleeping, I organized your day. Would you like a quick briefing?";
function Intro({ onDone }) {
	const [started, setStarted] = (0, import_react.useState)(false);
	const [typed, setTyped] = (0, import_react.useState)("");
	const [fading, setFading] = (0, import_react.useState)(false);
	const doneRef = (0, import_react.useRef)(false);
	const finish = () => {
		if (doneRef.current) return;
		doneRef.current = true;
		setFading(true);
		setTimeout(() => onDone(), 900);
	};
	const begin = () => {
		if (started) return;
		setStarted(true);
		let spoke = false;
		try {
			const synth = window.speechSynthesis;
			synth.cancel();
			const u = new SpeechSynthesisUtterance(INTRO_LINE);
			u.lang = "en-US";
			u.rate = .96;
			u.pitch = .85;
			u.volume = 1;
			const pickMaleVoice = () => {
				const voices = synth.getVoices();
				const score = (v) => {
					const n = v.name.toLowerCase();
					let s = 0;
					if (/en[-_]?(us|gb|au)/i.test(v.lang)) s += 3;
					else if (/^en/i.test(v.lang)) s += 2;
					if (/(male|man|david|daniel|alex|fred|guy|aaron|arthur|oliver|james|george|mark|tom|rishi|ravi)/i.test(n)) s += 5;
					if (/(female|woman|samantha|victoria|karen|moira|tessa|zira|jenny|aria|allison|ava|susan|fiona|catherine)/i.test(n)) s -= 5;
					if (/google.*us english/i.test(n)) s += 1;
					return s;
				};
				const chosen = [...voices].filter((v) => /^en/i.test(v.lang)).sort((a, b) => score(b) - score(a))[0];
				if (chosen) u.voice = chosen;
			};
			u.onend = () => finish();
			u.onerror = () => finish();
			const speakNow = () => {
				pickMaleVoice();
				synth.speak(u);
				spoke = true;
			};
			if (synth.getVoices().length) speakNow();
			else {
				synth.addEventListener("voiceschanged", () => {
					if (!spoke) speakNow();
				}, { once: true });
				setTimeout(() => {
					if (!spoke) speakNow();
				}, 400);
			}
		} catch {}
		setTimeout(() => finish(), 9e3);
	};
	(0, import_react.useEffect)(() => {
		if (!started) return;
		let i = 0;
		const tick = setInterval(() => {
			i++;
			setTyped(INTRO_LINE.slice(0, i));
			if (i >= 102) clearInterval(tick);
		}, 55);
		return () => clearInterval(tick);
	}, [started]);
	(0, import_react.useEffect)(() => {
		return () => {
			try {
				window.speechSynthesis.cancel();
			} catch {}
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-[100] flex flex-col items-center justify-center transition-opacity duration-[900ms]",
		style: {
			background: "#050505",
			opacity: fading ? 0 : 1,
			pointerEvents: fading ? "none" : "auto"
		},
		onClick: begin,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 opacity-60",
				style: { background: "radial-gradient(circle at 50% 50%, oklch(0.3 0.18 250 / 0.35), transparent 60%)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orb, { speaking: true })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-10 max-w-xl px-8 text-center min-h-[6rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] uppercase tracking-[0.5em] text-cyan/80 mb-3",
					style: { animation: "blink 1.6s infinite" },
					children: started ? "Shivang's PA · speaking" : "Shivang's PA · standby"
				}), started ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-foreground/90 text-lg leading-relaxed font-light",
					children: [typed, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-block w-[2px] h-[1.1em] align-[-2px] ml-1 bg-cyan",
						style: { animation: "type-cursor 0.9s infinite" }
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: begin,
					className: "text-foreground/80 text-sm tracking-[0.4em] uppercase font-mono px-6 py-3 rounded-full border border-white/15 hover:border-cyan/60 hover:text-cyan transition-colors",
					style: { animation: "orb-breathe 2.4s ease-in-out infinite" },
					children: "Tap to wake Shivang's PA"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute bottom-10 text-[10px] uppercase tracking-[0.5em] text-muted-foreground/60 font-mono",
				children: "Booting sentience layer · v3.0"
			})
		]
	});
}
function Sara() {
	const [speaking, setSpeaking] = (0, import_react.useState)(false);
	const [intro, setIntro] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!intro) setSpeaking(true);
	}, [intro]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen text-foreground",
		children: [
			intro && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Intro, { onDone: () => setIntro(false) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Particles, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 max-w-[1800px] mx-auto pb-8 transition-opacity duration-[1200ms]",
				style: { opacity: intro ? 0 : 1 },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
						speaking,
						setSpeaking
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "px-8 mt-6 grid grid-cols-12 gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-12 lg:col-span-3 space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SchedulePanel, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasksPanel, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherPanel, {})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-12 lg:col-span-6 space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "glass-strong rounded-2xl p-6 flex flex-col items-center justify-center min-h-[520px] relative overflow-hidden",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 grid-bg opacity-20" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "absolute top-4 left-4 flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-muted-foreground",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3 w-3 text-cyan" }), " Sentience layer"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "absolute top-4 right-4 text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono",
												children: "model · gemini-3-flash"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orb, { speaking }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-4 text-center max-w-md",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[10px] uppercase tracking-[0.4em] text-cyan/80 mb-1",
													children: "Now responding"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-foreground/85 text-sm leading-relaxed",
													children: "“You have five meetings today. I've prepared a one-page brief for your 11 AM sync with Sequoia and rescheduled the design review to make room.”"
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldMap, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Capabilities, {})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-12 lg:col-span-3 space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThinkingPanel, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Productivity, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsGrid, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickPanels, {})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraphsRow, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketsStrip, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewsTicker, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoiceBar, { speaking })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "px-8 mt-6 flex items-center justify-between text-[10px] uppercase tracking-[0.3em] text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "Shivang's PA · Personal AI Operating System" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_oklch(0.7_0.2_150)]",
								style: { animation: "blink 1.4s infinite" }
							}), "All systems nominal"]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Sara as component };
